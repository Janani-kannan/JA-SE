import type { Product } from "../types";

export const products: Product[] = [
  // Hot coffee
  {
    id: "rebel-cappuccino",
    name: "Rebel Cappuccino",
    description:
      "Double ristretto under velvety steamed milk, finished with a bold cocoa edge.",
    price: 220,
    category: "Hot coffee",
    art: "cappuccino",
    colors: ["#5a3420", "#f3e3cf", "#e0182d"],
    glow: "#7a1019",
    zone: "str",
    badge: "Signature",
  },
  {
    id: "mankatha-mocha",
    name: "Mankatha Mocha",
    description:
      "Dark chocolate melted into espresso and silky milk, topped with whipped cream.",
    price: 260,
    category: "Hot coffee",
    art: "mocha",
    colors: ["#3b2016", "#fff3e0", "#8d94a1"],
    glow: "#3a3d45",
    zone: "ak",
    badge: "Signature",
  },
  {
    id: "vinnaithaandi-vanilla",
    name: "Vinnaithaandi Vanilla",
    description:
      "A smooth vanilla bean latte with a soft, sweet finish and a heart on top.",
    price: 240,
    category: "Hot coffee",
    art: "vanilla",
    colors: ["#d8b27a", "#fff7ec", "#f2c23c"],
    glow: "#6e1520",
    zone: "str",
    badge: "Signature",
  },
  {
    id: "classic-espresso",
    name: "Classic Espresso",
    description:
      "A short, strong shot with thick golden crema. Nothing added, nothing hidden.",
    price: 150,
    category: "Hot coffee",
    art: "espresso",
    colors: ["#2a160c", "#d9a066", "#c9ced6"],
    glow: "#3a3d45",
    zone: "ak",
  },
  {
    id: "filter-kaapi",
    name: "Filter Kaapi",
    description:
      "South Indian decoction with frothy milk, poured tall in a steel tumbler and davara.",
    price: 120,
    category: "Hot coffee",
    art: "kaapi",
    colors: ["#8a5a34", "#f1dcc0", "#c9ced6"],
    glow: "#5a3a1c",
  },
  {
    id: "masala-chai-latte",
    name: "Masala Chai Latte",
    description:
      "Assam tea simmered with cardamom, ginger and clove, then topped with milk foam.",
    price: 180,
    category: "Hot coffee",
    art: "chai",
    colors: ["#a8683a", "#f3e3cf", "#4a2c18"],
    glow: "#5a3a1c",
  },
  {
    id: "caramel-macchiato",
    name: "Caramel Macchiato",
    description:
      "Vanilla milk marked with espresso and a lattice of salted caramel.",
    price: 270,
    category: "Hot coffee",
    art: "macchiato",
    colors: ["#c68a4e", "#f7ead3", "#8a4a12"],
    glow: "#6a4210",
  },

  // Cold coffee
  {
    id: "thala-cold-coffee",
    name: "Thala Cold Coffee",
    description:
      "Slow-chilled coffee over ice with cream, served cold and sharp, with a long finish.",
    price: 240,
    category: "Cold coffee",
    art: "iced",
    colors: ["#3b2016", "#a8734a", "#f3e3cf"],
    glow: "#3a3d45",
    zone: "ak",
    badge: "Signature",
  },
  {
    id: "chocolate-frappe",
    name: "Chocolate Frappe",
    description:
      "Blended dark chocolate and coffee, crowned with whipped cream and a chocolate drizzle.",
    price: 280,
    category: "Cold coffee",
    art: "frappe",
    colors: ["#4a2a1c", "#8a5a3c", "#fff3e0"],
    glow: "#5a2a1a",
    badge: "Signature",
  },
  {
    id: "hazelnut-cold-brew",
    name: "Hazelnut Cold Brew",
    description:
      "Eighteen hours steeped, poured over ice with a splash of toasted hazelnut.",
    price: 290,
    category: "Cold coffee",
    art: "coldbrew",
    colors: ["#1f100a", "#5a3420", "#c9ced6"],
    glow: "#3a3d45",
    zone: "ak",
  },

  // Desserts
  {
    id: "red-velvet-cake",
    name: "Red Velvet Cake",
    description:
      "Four soft red layers with cream cheese frosting and a crumb of velvet on top.",
    price: 240,
    category: "Desserts",
    art: "redvelvet",
    colors: ["#b3121f", "#fff1e6", "#e0182d"],
    glow: "#7a1019",
    zone: "str",
    badge: "Signature",
  },
  {
    id: "signature-brownie",
    name: "Signature Brownie",
    description:
      "Fudgy dark chocolate brownie with walnut and a glossy ganache glaze.",
    price: 200,
    category: "Desserts",
    art: "brownie",
    colors: ["#3b1f14", "#c68a4e", "#fff3e0"],
    glow: "#4a2418",
    badge: "Signature",
  },
  {
    id: "tiramisu-cup",
    name: "Tiramisu Cup",
    description:
      "Espresso-soaked sponge layered with mascarpone cream and bitter cocoa.",
    price: 260,
    category: "Desserts",
    art: "tiramisu",
    colors: ["#c9a06c", "#f6ead6", "#4a2c18"],
    glow: "#5a3a1c",
  },
  {
    id: "blueberry-cheesecake",
    name: "Blueberry Cheesecake",
    description:
      "Creamy baked cheesecake on a biscuit base with a tangy blueberry topping.",
    price: 280,
    category: "Desserts",
    art: "cheesecake",
    colors: ["#c9a06c", "#fbf1d8", "#3f4a9a"],
    glow: "#2a2f66",
  },

  // Snacks
  {
    id: "butter-croissant",
    name: "Butter Croissant",
    description:
      "Flaky, golden and layered by hand. Best with a hot espresso beside it.",
    price: 160,
    category: "Snacks",
    art: "croissant",
    colors: ["#d89a45", "#a8631f", "#f3d08a"],
    glow: "#5a3a1c",
  },
  {
    id: "peri-peri-fries",
    name: "Peri Peri Fries",
    description:
      "Crisp fries tossed in a fiery peri peri spice mix, served hot with a dip.",
    price: 170,
    category: "Snacks",
    art: "fries",
    colors: ["#e0182d", "#f2c23c", "#fff3e0"],
    glow: "#7a1019",
    zone: "str",
  },
  {
    id: "paneer-puff",
    name: "Paneer Puff",
    description:
      "Flaky pastry filled with spiced paneer, baked until crisp and golden.",
    price: 110,
    category: "Snacks",
    art: "puff",
    colors: ["#d89a45", "#a8631f", "#f3d08a"],
    glow: "#5a3a1c",
  },
  {
    id: "garlic-cheese-toast",
    name: "Garlic Cheese Toast",
    description:
      "Thick toast with garlic butter, melted cheese and herbs, grilled until bubbling.",
    price: 150,
    category: "Snacks",
    art: "toast",
    colors: ["#c68a4e", "#f6e2b8", "#f2c23c"],
    glow: "#5a3a1c",
  },
];

export const coffeeCategories = ["All", "Hot coffee", "Cold coffee"] as const;
export const dessertCategories = ["All", "Desserts", "Snacks"] as const;
