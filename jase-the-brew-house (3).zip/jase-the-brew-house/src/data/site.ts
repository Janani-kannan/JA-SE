// Replace the placeholder values below with your real cafe details.

export const site = {
  name: "JASÉ",
  fullName: "JASÉ – The Brew House",
  tagline: "Taste the rebel. Feel the class.",
  address: "Your street address, Chennai, Tamil Nadu",
  phone: "+91 00000 00000",
  email: "hello@your-domain.com",
  hours: [
    { days: "Monday to Friday", time: "8:00 am to 11:00 pm" },
    { days: "Saturday and Sunday", time: "8:00 am to 12:00 midnight" },
  ],
  // Replace with the link to your cafe on Google Maps
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=Chennai",
  social: {
    instagram: "https://www.instagram.com/",
    facebook: "https://www.facebook.com/",
    youtube: "https://www.youtube.com/",
    x: "https://x.com/",
  },
};

export const navLinks = [
  { href: "#about", label: "About" },
  { href: "#rebel-zone", label: "Rebel Zone" },
  { href: "#racing-zone", label: "Racing Zone" },
  { href: "#menu", label: "Menu" },
  { href: "#desserts", label: "Desserts" },
  { href: "#reviews", label: "Reviews" },
  { href: "#contact", label: "Contact" },
];

// Sample reviews for the demo. Replace with real customer feedback before launch.
export const reviews = [
  {
    name: "Arjun K.",
    text: "The Rebel Cappuccino has real bite. Strong, smooth and the cup itself looks like a poster.",
    stars: 5,
  },
  {
    name: "Meera S.",
    text: "Vinnaithaandi Vanilla with the brownie is now my Sunday plan. The place feels like a film set.",
    stars: 5,
  },
  {
    name: "Karthik R.",
    text: "Cold brew is clean and sharp. Good seats, good music, and the peri peri fries disappear fast.",
    stars: 4,
  },
  {
    name: "Divya P.",
    text: "Filter Kaapi in a proper tumbler and davara. Tastes like home, served with some swagger.",
    stars: 5,
  },
];
