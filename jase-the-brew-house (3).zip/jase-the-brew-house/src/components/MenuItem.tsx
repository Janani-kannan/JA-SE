import type { Product } from "../types";
import ItemArt from "./ItemArt";
import AddButton from "./AddButton";

interface MenuItemProps {
  item: Product;
  quantity: number;
  onAdd: (id: string) => void;
}

/** Horizontal menu row: image, name, description, price and an add button. */
export default function MenuItem({ item, quantity, onAdd }: MenuItemProps) {
  return (
    <article className="flex min-w-0 gap-3 rounded-3xl border border-white/10 bg-coal p-3 sm:gap-5 sm:p-4">
      <ItemArt
        kind={item.art}
        colors={item.colors}
        glow={item.glow}
        className="h-24 w-24 shrink-0 rounded-2xl sm:h-36 sm:w-36"
      />
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex flex-col gap-1 sm:flex-row sm:items-start sm:justify-between sm:gap-3">
          <h3 className="break-words font-display text-2xl font-extrabold uppercase leading-none tracking-wide sm:text-3xl">
            {item.name}
          </h3>
          <span className="shrink-0 font-display text-2xl font-extrabold text-crema sm:text-3xl">
            ₹{item.price}
          </span>
        </div>
        {item.badge && (
          <span className="mt-1 w-fit rounded-full bg-rebel/15 px-2.5 py-0.5 text-xs font-semibold text-[#ff7a88]">
            {item.badge}
          </span>
        )}
        <p className="mt-2 flex-1 text-sm leading-relaxed text-cream/70">
          {item.description}
        </p>
        <div className="mt-3">
          <AddButton
            quantity={quantity}
            onAdd={() => onAdd(item.id)}
            label={item.name}
          />
        </div>
      </div>
    </article>
  );
}
