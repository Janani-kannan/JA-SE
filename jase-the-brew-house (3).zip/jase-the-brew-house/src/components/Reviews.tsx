import { Star } from "lucide-react";
import { reviews } from "../data/site";

export default function Reviews() {
  return (
    <section id="reviews" className="scroll-mt-16 bg-coal py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <h2 className="font-display text-5xl font-extrabold uppercase leading-[0.9] sm:text-7xl">
          What guests say
        </h2>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {reviews.map((r) => (
            <figure
              key={r.name}
              className="flex flex-col rounded-3xl border border-white/10 bg-ink p-6"
            >
              <div
                className="flex gap-1 text-crema"
                role="img"
                aria-label={`${r.stars} out of 5 stars`}
              >
                {Array.from({ length: 5 }, (_, i) => (
                  <Star
                    key={i}
                    size={18}
                    fill={i < r.stars ? "currentColor" : "none"}
                    strokeWidth={1.5}
                  />
                ))}
              </div>
              <blockquote className="mt-4 flex-1 text-cream/85">
                {r.text}
              </blockquote>
              <figcaption className="mt-5 font-display text-xl font-bold tracking-wide">
                {r.name}
              </figcaption>
            </figure>
          ))}
        </div>

        <p className="mt-6 text-sm text-cream/50">
          These are sample reviews for the demo site. Replace them with real
          guest feedback before launch.
        </p>
      </div>
    </section>
  );
}
