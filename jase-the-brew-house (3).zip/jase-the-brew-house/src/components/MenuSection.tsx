import { useState } from "react";
import { coffeeCategories } from "../data/menu";
import type { CartState, Product } from "../types";
import FilterChips from "./FilterChips";
import MenuItem from "./MenuItem";

type Filter = (typeof coffeeCategories)[number];

interface MenuSectionProps {
  products: Product[];
  cart: CartState;
  onAdd: (id: string) => void;
}

export default function MenuSection({ products, cart, onAdd }: MenuSectionProps) {
  const [filter, setFilter] = useState<Filter>("All");

  const coffees = products.filter(
    (p) => p.category === "Hot coffee" || p.category === "Cold coffee"
  );
  const visible =
    filter === "All" ? coffees : coffees.filter((p) => p.category === filter);

  return (
    <section id="menu" className="scroll-mt-16 bg-coal py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <h2 className="font-display text-5xl font-extrabold uppercase leading-[0.9] sm:text-7xl">
          Signature coffee menu
        </h2>
        <p className="mt-4 max-w-xl text-lg text-cream/75">
          Every cup is made to order. Choose hot or cold, then add it to your
          cart.
        </p>

        <div className="mt-8">
          <FilterChips
            options={coffeeCategories}
            active={filter}
            onChange={setFilter}
            label="Filter coffee by type"
          />
        </div>

        <div className="mt-8 grid grid-cols-1 gap-4 lg:grid-cols-2">
          {visible.map((item) => (
            <MenuItem
              key={item.id}
              item={item}
              quantity={cart[item.id] ?? 0}
              onAdd={onAdd}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
