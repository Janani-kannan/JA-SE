import { useState } from "react";
import { dessertCategories } from "../data/menu";
import type { CartState, Product } from "../types";
import FilterChips from "./FilterChips";
import ProductCard from "./ProductCard";

type Filter = (typeof dessertCategories)[number];

interface DessertsSectionProps {
  products: Product[];
  cart: CartState;
  onAdd: (id: string) => void;
}

export default function DessertsSection({
  products,
  cart,
  onAdd,
}: DessertsSectionProps) {
  const [filter, setFilter] = useState<Filter>("All");

  const sweets = products.filter(
    (p) => p.category === "Desserts" || p.category === "Snacks"
  );
  const visible =
    filter === "All" ? sweets : sweets.filter((p) => p.category === filter);

  return (
    <section id="desserts" className="scroll-mt-16 bg-ink py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <h2 className="font-display text-5xl font-extrabold uppercase leading-[0.9] sm:text-7xl">
          Desserts and snacks
        </h2>
        <p className="mt-4 max-w-xl text-lg text-cream/75">
          Something sweet or something savoury to go with your cup.
        </p>

        <div className="mt-8">
          <FilterChips
            options={dessertCategories}
            active={filter}
            onChange={setFilter}
            label="Filter desserts and snacks"
          />
        </div>

        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {visible.map((item) => (
            <ProductCard
              key={item.id}
              item={item}
              quantity={cart[item.id] ?? 0}
              onAdd={onAdd}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
