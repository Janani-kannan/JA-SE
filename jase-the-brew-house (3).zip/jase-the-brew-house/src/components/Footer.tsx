import type { ReactNode } from "react";
import { navLinks, site } from "../data/site";

function SocialLink({
  href,
  label,
  children,
}: {
  href: string;
  label: string;
  children: ReactNode;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      aria-label={label}
      className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/20 text-cream/80 transition hover:border-rebel hover:bg-rebel hover:text-white"
    >
      <svg
        viewBox="0 0 24 24"
        width="20"
        height="20"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        {children}
      </svg>
    </a>
  );
}

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-ink">
      <div className="checker h-3" aria-hidden="true" />
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 sm:px-8 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <p className="font-display text-5xl font-black leading-none tracking-wider">
            JAS<span className="text-rebel">É</span>
          </p>
          <p className="mt-1 font-display text-lg font-bold tracking-[0.25em] text-silver">
            THE BREW HOUSE
          </p>
          <p className="mt-4 max-w-sm text-cream/70">
            Taste the rebel. Feel the class.
          </p>
          <div className="mt-6 flex gap-3">
            <SocialLink href={site.social.instagram} label="JASÉ on Instagram">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="0.6" fill="currentColor" />
            </SocialLink>
            <SocialLink href={site.social.facebook} label="JASÉ on Facebook">
              <path d="M14 8h3V4h-3a4 4 0 0 0-4 4v3H7v4h3v6h4v-6h3l1-4h-4V8z" />
            </SocialLink>
            <SocialLink href={site.social.youtube} label="JASÉ on YouTube">
              <rect x="2.5" y="5.5" width="19" height="13" rx="4" />
              <path d="m10 9.5 5 2.5-5 2.5z" fill="currentColor" />
            </SocialLink>
            <SocialLink href={site.social.x} label="JASÉ on X">
              <path d="M4 4l16 16M20 4 4 20" />
            </SocialLink>
          </div>
        </div>

        <nav aria-label="Footer">
          <p className="font-display text-xl font-bold tracking-wider text-silver">
            Explore
          </p>
          <ul className="mt-3 space-y-2 text-cream/80">
            {navLinks.map((l) => (
              <li key={l.href}>
                <a href={l.href} className="hover:text-white">
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="font-display text-xl font-bold tracking-wider text-silver">
            Visit
          </p>
          <p className="mt-3 text-cream/80">{site.address}</p>
          <p className="mt-2 text-cream/80">{site.phone}</p>
          <p className="text-cream/80">{site.email}</p>
        </div>
      </div>

      <div className="border-t border-white/10 px-5 py-6 text-center text-sm text-cream/50 sm:px-8">
        <p>
          JASÉ is an independent cafe inspired by Tamil cinema culture. It is not
          affiliated with, sponsored by or endorsed by any actor, film or
          production company.
        </p>
        <p className="mt-2">© {new Date().getFullYear()} JASÉ – The Brew House</p>
      </div>
    </footer>
  );
}
