import type { Product } from "../types";
import ItemArt from "./ItemArt";
import AddButton from "./AddButton";
import type { Tone } from "./AddButton";

interface ProductCardProps {
  item: Product;
  quantity: number;
  onAdd: (id: string) => void;
  tone?: Tone;
}

const frame: Record<Tone, string> = {
  default: "border-white/10 bg-coal",
  rebel: "border-rebel/40 bg-[#1a0508]",
  racing: "border-silver/30 bg-[#14161a]",
};

const priceTone: Record<Tone, string> = {
  default: "text-crema",
  rebel: "text-[#ff6b7a]",
  racing: "text-silver",
};

/** Vertical card: image on top, then name, description, price and add button. */
export default function ProductCard({
  item,
  quantity,
  onAdd,
  tone = "default",
}: ProductCardProps) {
  return (
    <article
      className={`flex flex-col overflow-hidden rounded-3xl border ${frame[tone]}`}
    >
      <ItemArt
        kind={item.art}
        colors={item.colors}
        glow={item.glow}
        className="aspect-square w-full"
      />
      <div className="flex flex-1 flex-col gap-2 p-5">
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-display text-2xl font-extrabold uppercase leading-none tracking-wide">
            {item.name}
          </h3>
          <span
            className={`shrink-0 font-display text-2xl font-extrabold ${priceTone[tone]}`}
          >
            ₹{item.price}
          </span>
        </div>
        <p className="flex-1 text-sm leading-relaxed text-cream/70">
          {item.description}
        </p>
        <div className="mt-3">
          <AddButton
            tone={tone}
            quantity={quantity}
            onAdd={() => onAdd(item.id)}
            label={item.name}
          />
        </div>
      </div>
    </article>
  );
}
