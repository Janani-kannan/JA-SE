import { useId } from "react";
import { ArrowDown, Coffee } from "lucide-react";

const CUP = "M88 172 H312 V220 C312 296 266 336 200 336 C134 336 88 296 88 220 Z";

function HeroCup() {
  const id = useId().replace(/:/g, "");
  return (
    <svg
      viewBox="0 0 400 400"
      className="w-full max-w-[440px]"
      role="img"
      aria-label="A coffee cup split in half: red on the left, silver on the right"
    >
      <defs>
        <linearGradient id={`${id}r`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ff4a5c" />
          <stop offset="1" stopColor="#7d0c19" />
        </linearGradient>
        <linearGradient id={`${id}s`} x1="1" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f6f8fa" />
          <stop offset="1" stopColor="#6f7785" />
        </linearGradient>
        <clipPath id={`${id}c`}>
          <path d={CUP} />
        </clipPath>
        <pattern id={`${id}k`} width="40" height="40" patternUnits="userSpaceOnUse">
          <rect width="20" height="20" fill="#000" opacity="0.4" />
          <rect x="20" y="20" width="20" height="20" fill="#000" opacity="0.4" />
          <rect x="20" width="20" height="20" fill="#fff" opacity="0.3" />
          <rect y="20" width="20" height="20" fill="#fff" opacity="0.3" />
        </pattern>
      </defs>

      <g fill="none" strokeWidth="7" strokeLinecap="round">
        <path className="steam" d="M160 130 q-14 -20 0 -38 q14 -18 0 -38" stroke="#ff6b7a" strokeOpacity="0.7" />
        <path className="steam steam-2" d="M200 124 q-14 -20 0 -38 q14 -18 0 -38" stroke="#ffffff" strokeOpacity="0.6" />
        <path className="steam steam-3" d="M240 130 q-14 -20 0 -38 q14 -18 0 -38" stroke="#c9ced6" strokeOpacity="0.7" />
      </g>

      <ellipse cx="200" cy="352" rx="176" ry="26" fill="#000" opacity="0.5" />
      <ellipse cx="200" cy="344" rx="170" ry="24" fill="#2a2c33" />
      <ellipse cx="200" cy="340" rx="150" ry="18" fill="#3a3d46" />

      <path
        d="M308 196 C376 184 388 268 322 288"
        fill="none"
        stroke="#c9ced6"
        strokeWidth="17"
        strokeLinecap="round"
      />

      <g clipPath={`url(#${id}c)`}>
        <rect x="80" y="160" width="120" height="190" fill={`url(#${id}r)`} />
        <rect x="200" y="160" width="120" height="190" fill={`url(#${id}s)`} />
        <rect x="80" y="236" width="240" height="34" fill={`url(#${id}k)`} />
        <rect x="198" y="160" width="4" height="190" fill="#09090b" opacity="0.8" />
      </g>

      <ellipse cx="200" cy="172" rx="112" ry="24" fill="#f3eee7" />
      <ellipse cx="200" cy="174" rx="100" ry="18" fill="#2a160c" />
      <ellipse cx="200" cy="174" rx="68" ry="11" fill="#8a5a34" />
      <ellipse cx="200" cy="174" rx="38" ry="6" fill="#f3e3cf" />

      {[
        [46, 340, 20],
        [354, 366, -30],
        [24, 312, 70],
      ].map(([x, y, r]) => (
        <g key={`${x}-${y}`} transform={`translate(${x} ${y}) rotate(${r})`}>
          <ellipse rx="13" ry="9" fill="#3b2016" />
          <path d="M-12 0 Q0 -5 12 0" fill="none" stroke="#1a0d07" strokeWidth="2" />
        </g>
      ))}
    </svg>
  );
}

const ticker = [
  "Taste the rebel",
  "Feel the class",
  "Where coffee meets cinema",
  "JASÉ – The Brew House",
];

export default function Hero() {
  return (
    <section id="home" className="relative overflow-hidden bg-ink">
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(55% 60% at 15% 38%, rgba(224,24,45,0.38), transparent 70%), radial-gradient(55% 60% at 88% 58%, rgba(201,206,214,0.24), transparent 70%)",
        }}
      />

      <div className="relative mx-auto grid max-w-7xl items-center gap-6 px-5 pb-20 pt-28 sm:px-8 lg:grid-cols-[1.15fr_1fr] lg:pb-28 lg:pt-32">
        <div>
          <p className="rise max-w-md text-lg text-cream/80">
            Where coffee meets cinema. A Tamil cinema-inspired brew house for
            people who like their coffee bold and their evenings cinematic.
          </p>
          <h1 className="rise rise-2 mt-5">
            <span className="block font-display text-[7rem] font-black uppercase leading-[0.8] tracking-tight sm:text-[10rem] lg:text-[12.5rem]">
              JAS<span className="text-rebel">É</span>
            </span>
            <span className="mt-2 block font-display text-2xl font-bold uppercase tracking-[0.3em] text-silver sm:text-4xl">
              The Brew House
            </span>
          </h1>
          <p className="rise rise-3 mt-8 font-display text-4xl font-extrabold uppercase leading-[0.95] sm:text-6xl">
            <span className="block text-rebel">Taste the rebel.</span>
            <span className="block text-silver">Feel the class.</span>
          </p>
          <div className="rise rise-4 mt-9 flex flex-wrap gap-3">
            <a
              href="#menu"
              className="inline-flex min-h-12 items-center gap-2 rounded-full bg-rebel px-7 font-bold text-white transition hover:bg-[#ff2b42]"
            >
              <Coffee size={18} aria-hidden="true" />
              Order now
            </a>
            <a
              href="#about"
              className="inline-flex min-h-12 items-center gap-2 rounded-full border border-silver/50 px-7 font-bold text-silver transition hover:bg-silver hover:text-ink"
            >
              Our story
              <ArrowDown size={18} aria-hidden="true" />
            </a>
          </div>
        </div>

        <div className="rise rise-3 flex justify-center lg:justify-end">
          <HeroCup />
        </div>
      </div>

      {/* Letterbox bar with ticker */}
      <div className="relative overflow-hidden border-y border-white/10 bg-black py-3" aria-hidden="true">
        <div className="marquee-track flex w-max items-center whitespace-nowrap">
          {[0, 1].map((n) => (
            <div key={n} className="flex items-center">
              {ticker.map((t) => (
                <span key={`${n}-${t}`} className="flex items-center">
                  <span className="px-6 font-display text-xl font-bold uppercase tracking-[0.2em] text-cream/80">
                    {t}
                  </span>
                  <Coffee size={16} className="text-rebel" />
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
