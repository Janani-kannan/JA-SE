import { Clapperboard, Coffee, Flag } from "lucide-react";

const points = [
  {
    icon: Coffee,
    title: "Coffee made with intent",
    text: "Espresso pulled carefully, cold brews steeped slowly and filter kaapi served the way it should be.",
  },
  {
    icon: Clapperboard,
    title: "A room with a story",
    text: "Dark walls, warm light and a soundtrack that makes an ordinary evening feel like a scene.",
  },
  {
    icon: Flag,
    title: "Two moods, one menu",
    text: "A loud red Rebel Zone and a sleek silver Racing Zone. Pick your side or drink from both.",
  },
];

export default function About() {
  return (
    <section id="about" className="scroll-mt-16 bg-coal py-20 sm:py-28">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 sm:px-8 lg:grid-cols-2 lg:items-center">
        <div className="grid grid-cols-2 gap-4">
          <div className="flex aspect-[4/5] flex-col justify-between rounded-3xl bg-gradient-to-br from-[#ff4a5c] to-rebel-deep p-5 sm:p-7">
            <span className="font-display text-[5.5rem] font-black leading-[0.8] sm:text-[8rem]">
              JA
            </span>
            <span className="font-display text-2xl font-bold uppercase tracking-widest sm:text-3xl">
              Janani
            </span>
          </div>
          <div className="flex aspect-[4/5] flex-col justify-between rounded-3xl bg-gradient-to-br from-[#f6f8fa] to-[#6f7785] p-5 text-ink sm:p-7">
            <span className="font-display text-[5.5rem] font-black leading-[0.8] sm:text-[8rem]">
              SE
            </span>
            <span className="font-display text-2xl font-bold uppercase tracking-widest sm:text-3xl">
              Selvan
            </span>
          </div>
        </div>

        <div>
          <h2 className="font-display text-5xl font-extrabold uppercase leading-[0.9] sm:text-7xl">
            Two names. One brew house.
          </h2>
          <p className="mt-6 max-w-xl text-lg text-cream/80">
            JASÉ is built from two names: JA for Janani and SE for Selvan. It is
            a cafe for people who grew up on Tamil cinema, big title cards and
            even bigger entrances, and who still want a really good cup of
            coffee at the end of the day.
          </p>
          <p className="mt-4 max-w-xl text-cream/60">
            JASÉ is an independent cafe inspired by Tamil cinema culture. It is
            not affiliated with or endorsed by any actor or film.
          </p>

          <ul className="mt-8 space-y-5">
            {points.map(({ icon: Icon, title, text }) => (
              <li key={title} className="flex gap-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-white/15 text-crema">
                  <Icon size={22} aria-hidden="true" />
                </span>
                <div>
                  <h3 className="font-display text-2xl font-bold uppercase tracking-wide">
                    {title}
                  </h3>
                  <p className="text-cream/70">{text}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
