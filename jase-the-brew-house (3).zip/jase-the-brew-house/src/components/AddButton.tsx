import { Plus } from "lucide-react";

export type Tone = "default" | "rebel" | "racing";

interface AddButtonProps {
  tone?: Tone;
  quantity: number;
  onAdd: () => void;
  label: string;
}

const toneClass: Record<Tone, string> = {
  default: "bg-cream text-ink hover:bg-white",
  rebel: "bg-rebel text-white hover:bg-[#ff2b42]",
  racing: "bg-silver text-ink hover:bg-white",
};

export default function AddButton({
  tone = "default",
  quantity,
  onAdd,
  label,
}: AddButtonProps) {
  return (
    <button
      type="button"
      onClick={onAdd}
      aria-label={`Add ${label} to cart${quantity ? `, ${quantity} in cart` : ""}`}
      className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold transition active:scale-95 ${toneClass[tone]}`}
    >
      <Plus size={16} strokeWidth={3} aria-hidden="true" />
      {quantity > 0 ? `Add more (${quantity})` : "Add to cart"}
    </button>
  );
}
