import { Clock, Mail, MapPin, Navigation, Phone } from "lucide-react";
import { site } from "../data/site";

export default function Contact() {
  const details = [
    { icon: MapPin, label: "Address", value: site.address },
    { icon: Phone, label: "Phone", value: site.phone },
    { icon: Mail, label: "Email", value: site.email },
  ];

  return (
    <section id="contact" className="scroll-mt-16 bg-ink py-20 sm:py-28">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 sm:px-8 lg:grid-cols-2">
        <div>
          <h2 className="font-display text-5xl font-extrabold uppercase leading-[0.9] sm:text-7xl">
            Come find us
          </h2>
          <p className="mt-4 max-w-md text-lg text-cream/75">
            Walk in for a quick espresso or stay for the evening. We would love
            to see you.
          </p>

          <ul className="mt-8 space-y-5">
            {details.map(({ icon: Icon, label, value }) => (
              <li key={label} className="flex gap-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-rebel/15 text-[#ff7a88]">
                  <Icon size={22} aria-hidden="true" />
                </span>
                <div className="min-w-0">
                  <p className="font-display text-xl font-bold tracking-wide text-silver">
                    {label}
                  </p>
                  <p className="break-words text-cream/85">{value}</p>
                </div>
              </li>
            ))}
          </ul>

          <a
            href={site.mapsUrl}
            target="_blank"
            rel="noreferrer"
            className="mt-8 inline-flex min-h-12 items-center gap-2 rounded-full bg-silver px-7 font-bold text-ink transition hover:bg-white"
          >
            <Navigation size={18} aria-hidden="true" />
            Get directions
          </a>
        </div>

        <div className="self-start overflow-hidden rounded-3xl border border-white/10 bg-coal">
          <div className="checker h-3" aria-hidden="true" />
          <div className="p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <Clock size={24} className="text-crema" aria-hidden="true" />
              <h3 className="font-display text-3xl font-extrabold uppercase tracking-wide">
                Opening hours
              </h3>
            </div>
            <dl className="mt-6 divide-y divide-white/10">
              {site.hours.map((h) => (
                <div
                  key={h.days}
                  className="flex flex-wrap justify-between gap-x-4 gap-y-1 py-4"
                >
                  <dt className="text-cream/70">{h.days}</dt>
                  <dd className="font-bold">{h.time}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </div>
    </section>
  );
}
