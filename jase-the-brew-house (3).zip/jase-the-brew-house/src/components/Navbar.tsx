import { useState } from "react";
import { Menu, ShoppingBag, X } from "lucide-react";
import { navLinks } from "../data/site";

interface NavbarProps {
  cartCount: number;
  cartPulse: number;
  onCartToggle: () => void;
}

export default function Navbar({
  cartCount,
  cartPulse,
  onCartToggle,
}: NavbarProps) {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed inset-x-0 top-0 z-30 border-b border-white/10 bg-ink/85 backdrop-blur-md">
      <nav
        className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8"
        aria-label="Main"
      >
        <a
          href="#home"
          className="flex items-baseline gap-2"
          onClick={() => setOpen(false)}
        >
          <span className="font-display text-3xl font-black leading-none tracking-wider">
            JAS<span className="text-rebel">É</span>
          </span>
          <span className="hidden font-display text-sm font-bold tracking-[0.25em] text-silver sm:inline">
            THE BREW HOUSE
          </span>
        </a>

        <ul className="hidden items-center gap-7 text-sm font-semibold text-cream/80 lg:flex">
          {navLinks.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="transition hover:text-white">
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onCartToggle}
            aria-label={`Open cart, ${cartCount} items`}
            className="relative inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/20 transition hover:border-rebel hover:bg-rebel/10"
          >
            <ShoppingBag size={20} aria-hidden="true" />
            {cartCount > 0 && (
              <span
                key={cartPulse}
                className="pop absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-rebel px-1 text-xs font-bold text-white"
              >
                {cartCount}
              </span>
            )}
          </button>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? "Close menu" : "Open menu"}
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/20 lg:hidden"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      {open && (
        <div
          id="mobile-menu"
          className="border-t border-white/10 bg-ink lg:hidden"
        >
          <ul className="mx-auto flex max-w-7xl flex-col px-5 py-3 sm:px-8">
            {navLinks.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block border-b border-white/5 py-3.5 font-display text-2xl font-bold uppercase tracking-wider text-cream/90 last:border-0"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
    </header>
  );
}
