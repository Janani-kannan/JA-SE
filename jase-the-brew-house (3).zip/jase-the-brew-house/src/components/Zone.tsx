import type { ReactNode } from "react";
import type { CartState, Product, Zone as ZoneId } from "../types";
import ProductCard from "./ProductCard";

interface ZoneProps {
  zone: ZoneId;
  id: string;
  products: Product[];
  cart: CartState;
  onAdd: (id: string) => void;
  title: string;
  quote: string;
  intro: string;
  icon: ReactNode;
}

/** Shared layout for the STR Rebel Zone and the AK Racing Zone. */
export default function Zone({
  zone,
  id,
  products,
  cart,
  onAdd,
  title,
  quote,
  intro,
  icon,
}: ZoneProps) {
  const rebel = zone === "str";
  const picks = products.filter((p) => p.zone === zone);

  return (
    <section
      id={id}
      className={`relative scroll-mt-16 overflow-hidden py-20 sm:py-28 ${
        rebel ? "bg-[#0f0305]" : "bg-[#0c0d10]"
      }`}
    >
      {rebel ? (
        <div
          aria-hidden="true"
          className="absolute -right-32 -top-24 h-[28rem] w-[28rem] rotate-12 bg-gradient-to-br from-rebel/40 to-transparent blur-2xl"
        />
      ) : (
        <>
          <div className="checker absolute inset-x-0 top-0 h-3" aria-hidden="true" />
          <div
            aria-hidden="true"
            className="absolute -left-24 top-10 h-[26rem] w-[26rem] -rotate-12 bg-gradient-to-br from-silver/25 to-transparent blur-2xl"
          />
        </>
      )}

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr] lg:items-end">
          <div>
            <span
              className={`inline-flex h-14 w-14 items-center justify-center rounded-2xl ${
                rebel ? "bg-rebel text-white" : "bg-silver text-ink"
              }`}
            >
              {icon}
            </span>
            <h2
              className={`mt-5 font-display text-5xl font-black uppercase leading-[0.9] sm:text-7xl ${
                rebel ? "text-white" : "text-silver"
              }`}
            >
              {title}
            </h2>
            <p
              className={`mt-3 font-display text-2xl font-bold uppercase tracking-wide sm:text-3xl ${
                rebel ? "text-rebel" : "text-chrome"
              }`}
            >
              {quote}
            </p>
          </div>
          <p className="max-w-lg text-lg text-cream/75">{intro}</p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {picks.map((item) => (
            <ProductCard
              key={item.id}
              item={item}
              quantity={cart[item.id] ?? 0}
              onAdd={onAdd}
              tone={rebel ? "rebel" : "racing"}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
