import { useEffect, useState } from "react";
import { Minus, Plus, Trash2, X } from "lucide-react";
import type { CartState, Product } from "../types";

interface CartDrawerProps {
  open: boolean;
  onClose: () => void;
  cart: CartState;
  products: Product[];
  onAdd: (id: string) => void;
  onRemove: (id: string) => void;
  onClear: () => void;
}

export default function CartDrawer({
  open,
  onClose,
  cart,
  products,
  onAdd,
  onRemove,
  onClear,
}: CartDrawerProps) {
  const [placed, setPlaced] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const lines = products.filter((p) => cart[p.id]);
  const total = lines.reduce((sum, p) => sum + p.price * cart[p.id], 0);

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Your cart">
      <button
        type="button"
        aria-label="Close cart"
        onClick={onClose}
        className="absolute inset-0 cursor-default bg-black/70"
      />
      <aside className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col border-l border-white/10 bg-coal">
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
          <h2 className="font-display text-3xl font-extrabold uppercase tracking-wide">
            Your cart
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close cart"
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/20"
          >
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-2">
          {lines.length === 0 ? (
            <p className="py-10 text-cream/70">
              Your cart is empty. Add a coffee or dessert from the menu.
            </p>
          ) : (
            <ul className="divide-y divide-white/10">
              {lines.map((p) => (
                <li key={p.id} className="flex items-center gap-3 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{p.name}</p>
                    <p className="text-sm text-cream/60">₹{p.price} each</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onRemove(p.id)}
                      aria-label={`Remove one ${p.name}`}
                      className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/25 hover:bg-white/10"
                    >
                      <Minus size={16} />
                    </button>
                    <span className="w-6 text-center font-bold tabular-nums">
                      {cart[p.id]}
                    </span>
                    <button
                      type="button"
                      onClick={() => onAdd(p.id)}
                      aria-label={`Add one more ${p.name}`}
                      className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/25 hover:bg-white/10"
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                  <p className="w-16 text-right font-bold tabular-nums">
                    ₹{p.price * cart[p.id]}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>

        {lines.length > 0 && (
          <div className="border-t border-white/10 px-5 py-5">
            <div className="flex items-center justify-between">
              <span className="font-display text-2xl font-bold uppercase">
                Total
              </span>
              <span className="font-display text-3xl font-extrabold text-crema tabular-nums">
                ₹{total}
              </span>
            </div>
            {placed && (
              <p className="mt-3 rounded-2xl bg-silver/10 p-3 text-sm text-cream/80">
                This is a demo store, so no order was sent and no payment was
                taken. Connect an ordering service to go live.
              </p>
            )}
            <div className="mt-4 flex gap-3">
              <button
                type="button"
                onClick={() => {
                  onClear();
                  setPlaced(false);
                }}
                className="inline-flex min-h-12 items-center gap-2 rounded-full border border-white/25 px-5 font-semibold hover:bg-white/10"
              >
                <Trash2 size={16} aria-hidden="true" />
                Clear
              </button>
              <button
                type="button"
                onClick={() => setPlaced(true)}
                className="min-h-12 flex-1 rounded-full bg-rebel px-5 font-bold text-white hover:bg-[#ff2b42]"
              >
                Place order
              </button>
            </div>
          </div>
        )}
      </aside>
    </div>
  );
}
