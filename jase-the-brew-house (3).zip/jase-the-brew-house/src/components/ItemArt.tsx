import { useId } from "react";
import type { ReactNode } from "react";
import type { ArtKind } from "../types";

interface ItemArtProps {
  kind: ArtKind;
  colors: [string, string, string];
  glow: string;
  className?: string;
}

const CERAMIC = "#ece8e2";
const CERAMIC_SHADE = "#cfc9c0";

function Steam({ tone = "#ffffff" }: { tone?: string }) {
  const common = {
    fill: "none",
    stroke: tone,
    strokeOpacity: 0.6,
    strokeWidth: 4,
    strokeLinecap: "round" as const,
  };
  return (
    <g>
      <path className="steam" d="M84 70 q-9 -12 0 -22 q9 -10 0 -22" {...common} />
      <path
        className="steam steam-2"
        d="M104 66 q-9 -12 0 -22 q9 -10 0 -22"
        {...common}
      />
      <path
        className="steam steam-3"
        d="M124 70 q-9 -12 0 -22 q9 -10 0 -22"
        {...common}
      />
    </g>
  );
}

function Cup({
  liquid,
  foam,
  accent,
  small = false,
  art,
}: {
  liquid: string;
  foam: string;
  accent: string;
  small?: boolean;
  art: "heart" | "rings" | "cream" | "none";
}) {
  const s = small ? 0.78 : 1;
  return (
    <g transform={`translate(${100 - 100 * s} ${small ? 34 : 6}) scale(${s})`}>
      <Steam />
      <ellipse cx="100" cy="158" rx="76" ry="13" fill={CERAMIC_SHADE} />
      <ellipse cx="100" cy="154" rx="72" ry="11" fill={CERAMIC} />
      <path
        d="M150 104 q30 0 26 24 q-4 20 -32 16"
        fill="none"
        stroke={CERAMIC}
        strokeWidth="9"
        strokeLinecap="round"
      />
      <path
        d="M48 96 H152 V116 C152 142 132 154 100 154 C68 154 48 142 48 116 Z"
        fill={CERAMIC}
      />
      <path
        d="M110 96 H152 V116 C152 142 132 154 100 154 C122 140 112 112 110 96Z"
        fill={CERAMIC_SHADE}
        opacity="0.55"
      />
      <rect x="48" y="118" width="104" height="7" fill={accent} opacity="0.9" />
      <ellipse cx="100" cy="96" rx="52" ry="11" fill={CERAMIC} />
      <ellipse cx="100" cy="97" rx="46" ry="8.5" fill={liquid} />
      {art === "heart" && (
        <path
          d="M100 104 c-14 -10 -24 -2 -16 6 l16 11 l16 -11 c8 -8 -2 -16 -16 -6z"
          transform="translate(0 -13) scale(1 0.55)"
          fill={foam}
        />
      )}
      {art === "rings" && (
        <>
          <ellipse cx="100" cy="97" rx="32" ry="5.5" fill={foam} opacity="0.9" />
          <ellipse cx="100" cy="97" rx="18" ry="3.2" fill={liquid} />
        </>
      )}
      {art === "cream" && (
        <>
          <ellipse cx="100" cy="94" rx="30" ry="6" fill={foam} />
          <ellipse cx="100" cy="88" rx="20" ry="5.5" fill={foam} />
          <ellipse cx="100" cy="82" rx="10" ry="4.5" fill={foam} />
        </>
      )}
    </g>
  );
}

function Glass({
  id,
  layers,
  cream,
  creamTone,
}: {
  id: string;
  layers: [string, string, string];
  cream?: boolean;
  creamTone?: string;
}) {
  const shape = "M62 46 H138 L126 162 Q125 170 117 170 H83 Q75 170 74 162 Z";
  return (
    <g>
      <ellipse cx="100" cy="174" rx="48" ry="8" fill="#000" opacity="0.35" />
      <clipPath id={id}>
        <path d={shape} />
      </clipPath>
      <path d={shape} fill="#ffffff" opacity="0.1" />
      <g clipPath={`url(#${id})`}>
        <rect x="60" y="128" width="84" height="50" fill={layers[0]} />
        <rect x="60" y="88" width="84" height="40" fill={layers[1]} />
        <rect x="60" y="46" width="84" height="42" fill={layers[2]} />
        <rect x="84" y="60" width="22" height="22" rx="4" fill="#fff" opacity="0.28" transform="rotate(14 95 71)" />
        <rect x="104" y="96" width="22" height="22" rx="4" fill="#fff" opacity="0.22" transform="rotate(-12 115 107)" />
        <rect x="76" y="118" width="20" height="20" rx="4" fill="#fff" opacity="0.2" transform="rotate(20 86 128)" />
      </g>
      <path d={shape} fill="none" stroke="#fff" strokeOpacity="0.7" strokeWidth="2.5" />
      <path d="M70 58 L76 150" stroke="#fff" strokeOpacity="0.4" strokeWidth="4" strokeLinecap="round" />
      {cream && (
        <g>
          <ellipse cx="100" cy="46" rx="36" ry="10" fill={creamTone ?? "#fff3e0"} />
          <ellipse cx="100" cy="34" rx="26" ry="9" fill={creamTone ?? "#fff3e0"} />
          <ellipse cx="100" cy="23" rx="14" ry="7" fill={creamTone ?? "#fff3e0"} />
          <path
            d="M72 44 q14 8 28 -2 q14 -8 30 2"
            fill="none"
            stroke={layers[0]}
            strokeWidth="4"
            strokeLinecap="round"
          />
        </g>
      )}
      <line
        x1="118"
        y1={cream ? 12 : 14}
        x2="98"
        y2="148"
        stroke="#e0182d"
        strokeWidth="6"
        strokeLinecap="round"
      />
    </g>
  );
}

function Plate({ children }: { children: ReactNode }) {
  return (
    <g>
      <ellipse cx="100" cy="164" rx="84" ry="14" fill={CERAMIC_SHADE} />
      <ellipse cx="100" cy="160" rx="80" ry="13" fill={CERAMIC} />
      <ellipse cx="100" cy="160" rx="56" ry="8" fill={CERAMIC_SHADE} opacity="0.5" />
      {children}
    </g>
  );
}

function Cake({
  layers,
  top,
  decor,
  decorTone,
  crumbTone,
}: {
  layers: [string, number][];
  top: string;
  decor: "crumbs" | "berries";
  decorTone: string;
  crumbTone: string;
}) {
  let y = 152;
  const rects = layers.map(([c, h], i) => {
    y -= h;
    return <rect key={i} x="48" y={y} width="104" height={h} fill={c} />;
  });
  const topY = y;
  return (
    <Plate>
      <g>
        {rects}
        <path
          d={`M44 ${topY + 2} q0 -16 16 -16 h80 q16 0 16 16 z`}
          fill={top}
        />
        {decor === "crumbs" &&
          [66, 84, 102, 120, 136].map((x, i) => (
            <circle key={x} cx={x} cy={topY - 14 + (i % 2) * 3} r="4" fill={crumbTone} />
          ))}
        {decor === "berries" &&
          [70, 92, 114, 134].map((x, i) => (
            <circle key={x} cx={x} cy={topY - 15 + (i % 2) * 3} r="6" fill={decorTone} />
          ))}
        <path
          d={`M150 ${topY - 10} q8 0 8 8 v${152 - topY - 8}`}
          fill="none"
          stroke="#000"
          strokeOpacity="0.12"
          strokeWidth="6"
        />
      </g>
    </Plate>
  );
}

function Croissant({ c1, c2, c3 }: { c1: string; c2: string; c3: string }) {
  const segs = [
    { x: 38, y: 130, r: -62, rx: 14, ry: 22 },
    { x: 62, y: 112, r: -34, rx: 19, ry: 28 },
    { x: 100, y: 104, r: 0, rx: 23, ry: 34 },
    { x: 138, y: 112, r: 34, rx: 19, ry: 28 },
    { x: 162, y: 130, r: 62, rx: 14, ry: 22 },
  ];
  return (
    <Plate>
      {segs.map((s, i) => (
        <g key={i} transform={`translate(${s.x} ${s.y}) rotate(${s.r})`}>
          <ellipse cx="0" cy="8" rx={s.rx} ry={s.ry} fill={c1} />
          <path
            d={`M${-s.rx + 4} 0 Q0 ${-s.ry * 0.5} ${s.rx - 4} 0`}
            fill="none"
            stroke={c2}
            strokeWidth="3"
            strokeLinecap="round"
          />
          <ellipse cx={-s.rx * 0.3} cy="-4" rx={s.rx * 0.3} ry={s.ry * 0.5} fill={c3} opacity="0.7" />
        </g>
      ))}
    </Plate>
  );
}

function Fries({ red, yellow, white }: { red: string; yellow: string; white: string }) {
  return (
    <g>
      <ellipse cx="100" cy="172" rx="48" ry="8" fill="#000" opacity="0.35" />
      {[-24, -14, -4, 6, 16, 26, 34].map((dx, i) => (
        <rect
          key={dx}
          x={96 + dx}
          y={30 + (i % 3) * 10}
          width="11"
          height="86"
          rx="3"
          fill={yellow}
          transform={`rotate(${dx * 0.55} ${100 + dx} 110)`}
        />
      ))}
      <path d="M60 98 H140 L130 168 Q129 172 124 172 H76 Q71 172 70 168 Z" fill={red} />
      <path d="M82 98 L84 172 H96 L94 98Z" fill={white} opacity="0.9" />
      <path d="M106 98 L108 172 H120 L118 98Z" fill={white} opacity="0.9" />
      {[60, 100, 140].map((x) => (
        <circle key={x} cx={x - 10 + (x % 3) * 8} cy={52 + (x % 4)} r="2.6" fill={red} />
      ))}
    </g>
  );
}

function Puff({ c1, c2, c3 }: { c1: string; c2: string; c3: string }) {
  return (
    <Plate>
      <path
        d="M100 64 L150 148 H50 Z"
        fill={c1}
        stroke={c1}
        strokeWidth="14"
        strokeLinejoin="round"
      />
      {[84, 98, 112, 126].map((y, i) => (
        <path
          key={y}
          d={`M${100 - (y - 64) * 0.55 + 4} ${y} Q100 ${y + 8} ${100 + (y - 64) * 0.55 - 4} ${y}`}
          fill="none"
          stroke={c2}
          strokeWidth="3"
          strokeLinecap="round"
          opacity={0.9 - i * 0.1}
        />
      ))}
      {[88, 100, 112].map((x, i) => (
        <circle key={x} cx={x} cy={74 + i * 2} r="2.4" fill={c3} />
      ))}
    </Plate>
  );
}

function Toast({ c1, c2, c3 }: { c1: string; c2: string; c3: string }) {
  return (
    <Plate>
      <g transform="rotate(-6 100 112)">
        <rect x="46" y="82" width="108" height="70" rx="18" fill={c1} />
        <rect x="54" y="90" width="92" height="54" rx="12" fill={c2} />
        <path
          d="M56 100 h88 v18 q-6 14 -12 4 q-6 12 -12 2 q-8 14 -14 2 q-8 12 -16 2 q-8 10 -14 0 q-10 8 -20 -4 z"
          fill={c3}
        />
        {[70, 92, 112, 130].map((x, i) => (
          <ellipse key={x} cx={x} cy={104 + (i % 2) * 8} rx="3.4" ry="1.8" fill="#4f8a3a" />
        ))}
      </g>
    </Plate>
  );
}

function Brownie({ c1, c2, c3 }: { c1: string; c2: string; c3: string }) {
  return (
    <Plate>
      <rect x="50" y="108" width="96" height="42" rx="7" fill={c1} />
      <rect x="50" y="108" width="96" height="9" rx="4" fill="#000" opacity="0.18" />
      <rect x="58" y="72" width="94" height="42" rx="7" fill="#2a130b" />
      <rect x="58" y="72" width="94" height="14" rx="6" fill="#4a2418" />
      <path
        d="M62 80 q14 10 28 0 q14 -10 28 0 q14 10 30 0"
        fill="none"
        stroke={c3}
        strokeWidth="4"
        strokeLinecap="round"
      />
      {[76, 100, 128].map((x, i) => (
        <path
          key={x}
          d={`M${x} ${92 + (i % 2) * 6} l8 -4 l6 6 l-5 7 l-9 -2z`}
          fill={c2}
        />
      ))}
    </Plate>
  );
}

function Tiramisu({ c1, c2, c3, id }: { c1: string; c2: string; c3: string; id: string }) {
  return (
    <g>
      <ellipse cx="100" cy="172" rx="54" ry="8" fill="#000" opacity="0.35" />
      <clipPath id={id}>
        <rect x="58" y="60" width="84" height="108" rx="12" />
      </clipPath>
      <rect x="58" y="60" width="84" height="108" rx="12" fill="#fff" opacity="0.1" />
      <g clipPath={`url(#${id})`}>
        <rect x="58" y="60" width="84" height="22" fill={c3} />
        <rect x="58" y="82" width="84" height="26" fill={c2} />
        <rect x="58" y="108" width="84" height="22" fill={c1} />
        <rect x="58" y="130" width="84" height="38" fill={c2} />
        {[70, 92, 114, 130].map((x) => (
          <circle key={x} cx={x} cy={71} r="2" fill="#fff" opacity="0.2" />
        ))}
      </g>
      <rect x="58" y="60" width="84" height="108" rx="12" fill="none" stroke="#fff" strokeOpacity="0.6" strokeWidth="2.5" />
      <rect x="112" y="44" width="14" height="40" rx="5" fill={c1} transform="rotate(16 119 64)" />
      <path d="M66 70 L70 150" stroke="#fff" strokeOpacity="0.4" strokeWidth="4" strokeLinecap="round" />
    </g>
  );
}

function Kaapi({ c1, c2, c3 }: { c1: string; c2: string; c3: string }) {
  return (
    <g>
      <Steam />
      <ellipse cx="100" cy="162" rx="70" ry="12" fill="#000" opacity="0.35" />
      <ellipse cx="100" cy="150" rx="66" ry="15" fill={c3} />
      <ellipse cx="100" cy="146" rx="56" ry="11" fill="#9aa1ad" />
      <path d="M68 84 H132 L124 148 H76 Z" fill={c3} />
      <path d="M108 84 H132 L124 148 H112 Z" fill="#8d94a1" opacity="0.6" />
      <ellipse cx="100" cy="84" rx="32" ry="7" fill={c3} />
      <ellipse cx="100" cy="85" rx="28" ry="5.4" fill={c1} />
      <ellipse cx="100" cy="85" rx="22" ry="3.6" fill={c2} />
    </g>
  );
}

export default function ItemArt({ kind, colors, glow, className }: ItemArtProps) {
  const uid = useId().replace(/:/g, "");
  const [c1, c2, c3] = colors;

  let art: ReactNode;
  switch (kind) {
    case "cappuccino":
      art = <Cup liquid={c1} foam={c2} accent={c3} art="heart" />;
      break;
    case "mocha":
      art = <Cup liquid={c1} foam={c2} accent={c3} art="cream" />;
      break;
    case "vanilla":
      art = <Cup liquid={c1} foam={c2} accent={c3} art="rings" />;
      break;
    case "espresso":
      art = <Cup liquid={c1} foam={c2} accent={c3} art="rings" small />;
      break;
    case "chai":
      art = <Cup liquid={c1} foam={c2} accent={c3} art="rings" />;
      break;
    case "macchiato":
      art = <Cup liquid={c1} foam={c2} accent={c3} art="rings" />;
      break;
    case "iced":
      art = <Glass id={uid} layers={[c1, c2, c3]} />;
      break;
    case "coldbrew":
      art = <Glass id={uid} layers={[c1, c2, c3]} />;
      break;
    case "frappe":
      art = <Glass id={uid} layers={[c1, c2, c2]} cream creamTone={c3} />;
      break;
    case "redvelvet":
      art = (
        <Cake
          layers={[[c1, 18], [c2, 7], [c1, 18], [c2, 7], [c1, 18]]}
          top={c2}
          decor="crumbs"
          decorTone={c1}
          crumbTone={c3}
        />
      );
      break;
    case "cheesecake":
      art = (
        <Cake
          layers={[[c1, 14], [c2, 46]]}
          top={c2}
          decor="berries"
          decorTone={c3}
          crumbTone={c3}
        />
      );
      break;
    case "brownie":
      art = <Brownie c1={c1} c2={c2} c3={c3} />;
      break;
    case "tiramisu":
      art = <Tiramisu c1={c1} c2={c2} c3={c3} id={uid} />;
      break;
    case "croissant":
      art = <Croissant c1={c1} c2={c2} c3={c3} />;
      break;
    case "fries":
      art = <Fries red={c1} yellow={c2} white={c3} />;
      break;
    case "puff":
      art = <Puff c1={c1} c2={c2} c3={c3} />;
      break;
    case "toast":
      art = <Toast c1={c1} c2={c2} c3={c3} />;
      break;
    case "kaapi":
      art = <Kaapi c1={c1} c2={c2} c3={c3} />;
      break;
  }

  return (
    <div
      className={`relative overflow-hidden ${className ?? ""}`}
      style={{
        background: `radial-gradient(circle at 50% 38%, ${glow} 0%, #0b0b0d 78%)`,
      }}
    >
      <svg
        viewBox="0 0 200 200"
        className="h-full w-full"
        role="img"
        aria-label={`Illustration of ${kind}`}
      >
        {art}
      </svg>
    </div>
  );
}
