interface FilterChipsProps<T extends string> {
  options: readonly T[];
  active: T;
  onChange: (value: T) => void;
  label: string;
}

export default function FilterChips<T extends string>({
  options,
  active,
  onChange,
  label,
}: FilterChipsProps<T>) {
  return (
    <div className="flex flex-wrap gap-2" role="group" aria-label={label}>
      {options.map((o) => (
        <button
          key={o}
          type="button"
          onClick={() => onChange(o)}
          aria-pressed={active === o}
          className={`min-h-11 rounded-full border px-5 text-sm font-bold transition ${
            active === o
              ? "border-cream bg-cream text-ink"
              : "border-white/25 text-cream/80 hover:border-white/60"
          }`}
        >
          {o}
        </button>
      ))}
    </div>
  );
}
