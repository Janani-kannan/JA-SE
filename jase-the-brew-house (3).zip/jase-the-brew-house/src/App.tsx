import { useCallback, useState } from "react";
import { Flag, Flame } from "lucide-react";
import { products } from "./data/menu";
import type { CartState } from "./types";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Zone from "./components/Zone";
import MenuSection from "./components/MenuSection";
import DessertsSection from "./components/DessertsSection";
import Reviews from "./components/Reviews";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import CartDrawer from "./components/CartDrawer";

export default function App() {
  const [cart, setCart] = useState<CartState>({});
  const [cartOpen, setCartOpen] = useState(false);
  const [cartPulse, setCartPulse] = useState(0);

  const addToCart = useCallback((id: string) => {
    setCart((prev) => ({ ...prev, [id]: (prev[id] ?? 0) + 1 }));
    setCartPulse((n) => n + 1);
  }, []);

  const removeFromCart = useCallback((id: string) => {
    setCart((prev) => {
      const next = { ...prev };
      if ((next[id] ?? 0) <= 1) delete next[id];
      else next[id] -= 1;
      return next;
    });
  }, []);

  const clearCart = useCallback(() => setCart({}), []);
  const closeCart = useCallback(() => setCartOpen(false), []);

  const cartCount = Object.values(cart).reduce((sum, n) => sum + n, 0);

  return (
    <>
      <Navbar
        cartCount={cartCount}
        cartPulse={cartPulse}
        onCartToggle={() => setCartOpen((v) => !v)}
      />
      <main>
        <Hero />
        <About />
        <Zone
          zone="str"
          id="rebel-zone"
          title="STR – Rebel Zone"
          quote="Born loud. Brewed louder."
          intro="Red lights, big flavours and no apologies. These are the cups and plates for people who walk in like it is their opening scene."
          icon={<Flame size={28} aria-hidden="true" />}
          products={products}
          cart={cart}
          onAdd={addToCart}
        />
        <Zone
          zone="ak"
          id="racing-zone"
          title="AK – Racing Zone"
          quote="Sleek. Sharp. Built for the long run."
          intro="Black, silver and precise. Clean espresso, cold brews and chocolate with a finish as smooth as a pit lane straight."
          icon={<Flag size={28} aria-hidden="true" />}
          products={products}
          cart={cart}
          onAdd={addToCart}
        />
        <MenuSection products={products} cart={cart} onAdd={addToCart} />
        <DessertsSection products={products} cart={cart} onAdd={addToCart} />
        <Reviews />
        <Contact />
      </main>
      <Footer />
      <CartDrawer
        open={cartOpen}
        onClose={closeCart}
        cart={cart}
        products={products}
        onAdd={addToCart}
        onRemove={removeFromCart}
        onClear={clearCart}
      />
    </>
  );
}
