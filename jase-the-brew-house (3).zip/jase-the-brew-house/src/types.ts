export type Category = "Hot coffee" | "Cold coffee" | "Desserts" | "Snacks";

export type ArtKind =
  | "cappuccino"
  | "mocha"
  | "vanilla"
  | "espresso"
  | "kaapi"
  | "chai"
  | "macchiato"
  | "iced"
  | "frappe"
  | "coldbrew"
  | "redvelvet"
  | "cheesecake"
  | "brownie"
  | "tiramisu"
  | "croissant"
  | "fries"
  | "puff"
  | "toast";

export type Zone = "str" | "ak";

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: Category;
  art: ArtKind;
  /** Three colours the illustration is painted with */
  colors: [string, string, string];
  /** Background glow behind the illustration */
  glow: string;
  zone?: Zone;
  badge?: string;
}

export type CartState = Record<string, number>;
