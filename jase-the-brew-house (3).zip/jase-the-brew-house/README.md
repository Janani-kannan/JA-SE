# JASÉ – The Brew House ☕

**Taste the rebel. Feel the class.**
*Where coffee meets cinema.*

A premium, cinematic, fully responsive cafe website with a Tamil cinema-inspired identity. Built with React, TypeScript, Vite, Tailwind CSS and Lucide React icons.

> **Disclaimer:** JASÉ is an independent cafe concept inspired by Tamil cinema culture. It is not affiliated with, sponsored by or endorsed by any actor, film or production company. All artwork in this project is original and drawn in code.

JASÉ is built from two names: **JA** for Janani and **SE** for Selvan.

## Features

- Cinematic hero with a split red and silver cup, film grain, letterbox ticker and steam animation
- Sections: Home, About, STR – Rebel Zone, AK – Racing Zone, Signature Coffee Menu, Desserts and Snacks, Customer Reviews, Contact and Location, Footer with social links
- 18 menu items (the 8 required items plus 10 extras), each with an image, name, description and price in ₹
- Fully responsive, mobile-first layout for phones, tablets and desktops
- Reduced-motion support and visible keyboard focus

### React state (`useState`)

| Feature | Where |
| --- | --- |
| Add to Cart and live cart quantity | `src/App.tsx` (cart state), badge in `Navbar.tsx` |
| Show / hide cart | `src/App.tsx` (`cartOpen`), `CartDrawer.tsx` |
| Category filtering | `MenuSection.tsx`, `DessertsSection.tsx` |
| Mobile navigation menu | `Navbar.tsx` |

### Reusable components

`Navbar`, `MenuItem`, `ProductCard`, `Footer`, `AddButton`, `FilterChips`, `Zone`, `CartDrawer`, `ItemArt`. Menu items are rendered from the `products` array in `src/data/menu.ts` using `map()`.

## Run locally

You need [Node.js](https://nodejs.org) 20 or newer.

```bash
npm install
npm run dev
```

Open the address printed in the terminal (usually http://localhost:5173).

```bash
npm run build     # type-check and create the production build in dist/
npm run preview   # serve the production build locally
```

## Customise

- **Menu:** edit `src/data/menu.ts`. Add an item to the array and it appears automatically.
- **Address, phone, email, hours, social links and reviews:** edit `src/data/site.ts`. The values there are placeholders. The reviews are samples, so replace them with real guest feedback.
- **Colours and fonts:** edit the `@theme` block in `src/index.css`.
- **Photos:** the dishes use original SVG illustrations in `src/components/ItemArt.tsx`. To use real photos, add your own or properly licensed images and swap them into `MenuItem.tsx` and `ProductCard.tsx`.

## Upload to GitHub

1. Sign in to GitHub and create a **new empty repository** (for example `jase-the-brew-house`). Do not add a README, .gitignore or licence there.
2. Copy the repository URL GitHub shows you, for example `https://github.com/YOUR-USERNAME/jase-the-brew-house.git`.
3. In the project folder, run the commands below. Replace `YOUR_GITHUB_REPOSITORY_URL` with the URL you just copied.

```bash
git init
git add .
git commit -m "Initial commit - JASE The Brew House"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

`.gitignore` already excludes `node_modules`, `dist` and environment files. This project needs no API keys or secrets. If you add any later, keep them in a `.env` file, which is never uploaded.

## Deploy on Vercel

1. Sign in at [vercel.com](https://vercel.com) with your GitHub account.
2. Click **Add New… → Project** and **Import** your `jase-the-brew-house` repository.
3. Vercel detects Vite. Confirm the settings (they are also set in `vercel.json`):
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
4. Click **Deploy** and wait about a minute.
5. When it finishes, Vercel shows your public live URL, for example `https://jase-the-brew-house.vercel.app`. You can also find it later under the project's **Domains** section.

Every time you push to `main`, Vercel redeploys automatically.

## Tech stack

React 19 · TypeScript · Vite · Tailwind CSS 4 · Lucide React
